﻿using System.ComponentModel.DataAnnotations;

namespace CrudMVC.Models
{               //aqui vai criar a tabela do banco
    public class Produto
    {
        [Key]// declara como chave primaria
        public int ProdutoId { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public decimal Preco { get; set; }

        public string Descricao { get; set; }
    }
}
